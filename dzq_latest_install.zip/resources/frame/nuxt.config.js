plugins: [
  '@/plugins/vue-auth-image.js'
]