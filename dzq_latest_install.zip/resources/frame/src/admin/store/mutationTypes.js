/**
 * 注册所有type 类型
 */

//网站公共模块
export const SET_LOADING = "SET_LOADING";
export const SET_NUM = 'SET_NUM';

//登录模块
export const SET_LOGIN_STATE = 'SET_LOGIN_STATE';

//admin后台模块
export const SET_SEARCH_CONDITION = 'SET_SEARCH_CONDITION';






