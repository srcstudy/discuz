<template>
    <div class="table-no-list">
      <p>暂无数据</p>
    </div>
</template>

<script>
export default {
    name: "table-no-list"
}
</script>

<style scoped>
.table-no-list{
  width: 100%;
  height: 45PX;
  text-align: center;
}
p{
  line-height: 45PX;
  color: #909399;
}
</style>
