/**
 * 卡片控制器
 */

export default {
  data:function () {
    return {

    }
  }
}
