/**
 * 内容主体
 */


export default {
  data:function () {
    return {
      // contText:"双电费"
    }
  },
  methods:{

  },
  created(){
    // this.contText = this.$attrs.contText;
  }
}
