/**
 * 注册所有type 类型
 */

//网站公共模块
export const SET_STATUS = 'SET_STATUS';
export const SET_OPENID = 'SET_OPENID';
export const SET_FORUM = 'SET_FORUM';
export const SET_FORUM_PROMISE = 'SET_FORUM_PROMISE';
export const SET_FORUM_STATE = 'SET_FORUM_STATE';
export const SET_USER = 'SET_USER';
export const SET_USER_STATE = 'SET_USER_STATE';
export const SET_USER_PROMISE = 'SET_USER_PROMISE';









