<?php
    return [
        'id' => '用户ID',
        'username' => '用户名',
        'mobile' => '手机号',
        'originalMobile' => '手机号',
        'status' => '帐号状态',
        'sex' => '性别',
        'groups' => '用户组名',
        'mp_openid' => '微信openid',
        'unionid' => '微信unionID',
        'nickname' => '微信昵称',
        'created_at' => '注册时间',
        'register_ip' => '注册IP',
        'register_port' => '注册端口',
        'login_at' => '最后登录时间',
        'last_login_ip' => '最后登录ip',
    ];
