<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Wechat - Offiaccount
    |--------------------------------------------------------------------------
    */

    // JSSDK
    'wechat_invalid_unknown_url_exception' => '无效未知url地址',
    'wechat_invalid_config_exception' => '无效配置异常',
    'wechat_runtime_exception' => '运行时异常',
    'wechat_invalid_argument_exception' => '无效参数异常',

    // reply
    'wechat_only_one_message_fail' => '该消息类型只允许创建一条',
];
