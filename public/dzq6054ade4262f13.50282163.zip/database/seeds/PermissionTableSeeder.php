<?php

/**
 * Copyright (C) 2020 Tencent Cloud.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

use App\Models\Permission;
use App\Models\Thread;
use Illuminate\Database\Seeder;

class PermissionTableSeeder extends Seeder
{
    /**
     * 默认用户组 1 为超级管理员有以下的所有权限
     *
     * @var array
     */
    protected $permissions = [
        // 用户
        'user.view' => [7, 10],                 // 查看某个用户信息权限
        'user.view.mobile' => [],               // 是否能查看用户真实手机号
        'user.edit' => [],                      // 编辑某个用户信息权限，除自己以外
        'user.delete' => [],                    // 删除某个用户信息权限

        // 用户组
        'group.create' => [],                   // 添加用户组权限
        'group.delete' => [],                   // 删除用户组权限

        // 分类
        'createCategory' => [],                 // 创建分类
        'category.delete' => [],                // 删除分类
        'category.edit' => [],                  // 修改分类

        // 默认分类下的权限
        'switch.viewThreads' => [7, 10],        // 查看主题列表
        'category1.viewThreads' => [7, 10],     // 查看主题列表
        'switch.createThread' => [10],          // 发布主题
        'category1.createThread' => [10],       // 发布主题
        'switch.thread.reply' => [10],          // 发布回复
        'category1.thread.reply' => [10],       // 发布回复
        'switch.thread.viewPosts' => [7, 10],   // 查看主题详情
        'category1.thread.viewPosts' => [7, 10],// 查看主题详情
        'category1.thread.editPosts' => [],     // 编辑回复
        'category1.thread.hidePosts' => [],     // 删除回复
        'category1.thread.canBeReward' => [],   // 帖子允许被打赏

        // 主题
        'createThread.' . Thread::TYPE_OF_TEXT => [10],             // 发布文字
        'createThread.' . Thread::TYPE_OF_LONG => [10],             // 发布帖子
        'createThread.' . Thread::TYPE_OF_VIDEO => [],              // 发布图片
        'createThread.' . Thread::TYPE_OF_IMAGE => [10],            // 发布视频
        'createThread.' . Thread::TYPE_OF_AUDIO => [],              // 发布语音
        'createThread.' . Thread::TYPE_OF_QUESTION => [10],         // 发布问答
        'createThread.' . Thread::TYPE_OF_GOODS => [10],            // 发布商品
        'createThread.' . Thread::TYPE_OF_TEXT . '.position' => [10],       // 发布文字位置
        'createThread.' . Thread::TYPE_OF_LONG . '.position' => [10],       // 发布长文位置
        'createThread.' . Thread::TYPE_OF_VIDEO . '.position' => [10],      // 发布视频位置
        'createThread.' . Thread::TYPE_OF_IMAGE . '.position' => [10],      // 发布图片位置
        'createThread.' . Thread::TYPE_OF_AUDIO . '.position' => [10],      // 发布语音位置
        'createThread.' . Thread::TYPE_OF_QUESTION . '.position' => [10],   // 发布问答位置
        'createThread.' . Thread::TYPE_OF_GOODS . '.position' => [10],      // 发布商品位置
        'thread.rename' => [],                  // 修改主题标题
        'thread.favorite' => [10],              // 收藏主题
        'createThreadWithCaptcha' => [],        // 发布主题验证验证码
        'publishNeedRealName' => [],            // 发布内容需先实名认证
        'publishNeedBindPhone' => [],           // 发布内容需先绑定手机

        // 回复
        'thread.likePosts' => [10],             // 点赞回复

        // 内容审核
        'thread.approvePosts' => [],            // 审核主题或回复

        // 回收站
        'viewTrashed' => [],                    // 查看回收站

        // 附件
        'attachment.create.0' => [10],          // 上传附件
        'attachment.create.1' => [10],          // 上传图片
        'attachment.create.0' => [6],          // 待付费用户支持上传附件
        'attachment.create.1' => [6],          // 待付费用户支持上传图片
        'attachment.delete' => [],              // 删除附件

        // 敏感词
        'stopWord.create' => [],                // 创建敏感词
        'stopWord.delete' => [],                // 删除敏感词

        // 站点
        'viewSiteInfo' => [],                   // 查看站点信息权限
        'checkVersion' => [],                   // 检查是否有新版权限
        'setting.site' => [],                   // 上传站点logo

        // 订单
        'order.create' => [6, 10],              // 创建订单
        'order.viewList' => [],                 // 订单总列表

        // 钱包
        'wallet.update' => [],                  // 更新钱包
        'wallet.viewList' => [],                // 总钱包信息列表
        'wallet.logs.viewList' => [],           // 钱包动账记录总列表
        'trade.pay.order' => [6, 10],           // 支付订单

        // 提现
        'cash.create' => [10],                  // 申请提现
        'cash.review' => [],                    // 提现审核
        'cash.viewList' => [],                  // 提现总列表

        // 邀请
        'createInvite' => [],                   // 发起邀请

        // 财务
        'statistic.financeProfile' => [],       // 财务概况
        'statistic.financeChart' => [],         // 财务图表

        // 短消息
        'dialog.create' => [10],                // 创建会话、会话消息

        // 关注
        'userFollow.create' => [10],            // 创建关注
    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = collect($this->permissions)->map(function ($value, $key) {
            return collect($value)->map(function ($value) use ($key) {
                return [
                    'group_id' => $value,
                    'permission' => $key
                ];
            });
        })->reduce(function ($value, $item) {
            return $item->merge($value);
        });

        Permission::query()->truncate();
        Permission::query()->insert($data->toArray());
    }
}
