<?php

return [
    'week' => '周',
    'month' => '月',
];
