<?php

return [
    'residue_degree' => '登录失败，您还可以尝试:values次',
    'WebUser_img_error' => '二维码生成失败',
    'WebUser_login_success' => '登录成功',
    'WebNewUser_login_success' => '扫码成功',
    'WebUser_img_payload_error' => '用户未扫码',
];
