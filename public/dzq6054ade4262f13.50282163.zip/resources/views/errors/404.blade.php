@extends('errors.minimal')

@section('title', 'Not Found')
@section('code', '404')
@section('message', 'Not Found')
